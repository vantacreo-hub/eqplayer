# EQ Player (Android 9 / Redmi Note 8)

Pemutar musik lokal dengan equalizer 30 band buatan sendiri.

```
Audio file decoder   MediaExtractor + MediaCodec        (AudioEngine.kt)
        ↓
PCM audio buffer     float interleaved
        ↓
30-band DSP          biquad peaking 1/3 oktaf, ±12 dB   (EqDsp.kt)
        ↓
Limiter / Volume     peak limiter 0.97 + volume         (AudioEngine.kt)
        ↓
AudioTrack           PCM 16-bit, mode stream
        ↓
Speaker / Headphone
```

- `SpectrumAnalyzer.kt` : FFT 1024 titik dari PCM hasil DSP (tanpa izin mikrofon)
- `BandSliderView.kt`   : slider vertikal tiap band
- `MainActivity.kt`     : daftar lagu, kontrol, preset, 30 slider

## Build
Buka folder ini di Android Studio (JDK 17), sambungkan HP (Debugging USB), tekan Run.
APK: Build > Build APK(s).
