plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.eqplayer"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.eqplayer"
        minSdk = 28          // Android 9 (Redmi Note 8)
        targetSdk = 28       // Android 9: akses file audio langsung, tanpa scoped storage
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        disable += "ExpiredTargetSdkVersion"
    }
}
