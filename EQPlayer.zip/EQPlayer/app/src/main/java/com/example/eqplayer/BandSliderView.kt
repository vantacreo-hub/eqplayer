package com.example.eqplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.round

/** Slider vertikal untuk satu band equalizer (-12 s/d +12 dB, langkah 0,5 dB). */
class BandSliderView(context: Context, private val label: String) : View(context) {

    var min = EqDsp.MIN_DB
    var max = EqDsp.MAX_DB
    var value = 0f
        set(v) {
            field = v.coerceIn(min, max)
            invalidate()
        }
    var onChange: ((Float) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.LTGRAY
        textAlign = Paint.Align.CENTER
        textSize = 11f * density
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3A3A3C")
        strokeWidth = 4f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5A0")
        strokeWidth = 4f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val zeroTick = Paint().apply {
        color = Color.GRAY
        strokeWidth = 1f * density
    }

    private val topPad get() = 22f * density
    private val bottomPad get() = 22f * density

    private fun yFor(v: Float): Float {
        val top = topPad
        val bottom = height - bottomPad
        return bottom - (v - min) / (max - min) * (bottom - top)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val top = topPad
        val bottom = height - bottomPad
        val zeroY = yFor(0f)
        val y = yFor(value)

        canvas.drawLine(cx, top, cx, bottom, trackPaint)
        canvas.drawLine(cx, zeroY, cx, y, fillPaint)
        canvas.drawLine(cx - 8f * density, zeroY, cx + 8f * density, zeroY, zeroTick)
        canvas.drawCircle(cx, y, 8f * density, thumb)

        val db = if (value > 0f) "+%.1f".format(value) else "%.1f".format(value)
        canvas.drawText(db, cx, 14f * density, text)
        canvas.drawText(label, cx, height - 6f * density, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val top = topPad
                val bottom = height - bottomPad
                val frac = 1f - ((e.y - top) / (bottom - top)).coerceIn(0f, 1f)
                val raw = min + frac * (max - min)
                val snapped = round(raw * 2f) / 2f
                if (snapped != value) {
                    value = snapped
                    onChange?.invoke(snapped)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }
}
