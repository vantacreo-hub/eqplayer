package com.example.eqplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.max

/** Tampilan spektrum real-time (32 batang) dari hasil FFT di SpectrumAnalyzer. */
class SpectrumView(context: Context) : View(context) {

    private val bars = FloatArray(SpectrumAnalyzer.BARS)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#00E5A0") }
    private val bg = Paint().apply { color = Color.parseColor("#1C1C1E") }

    /** Dipanggil dari thread audio. */
    fun update(levels: FloatArray) {
        for (i in bars.indices) bars[i] = max(levels[i], bars[i] * 0.8f)
        postInvalidate()
    }

    /** Dipanggil dari thread UI saat tidak ada audio yang diputar. */
    fun decay() {
        var any = false
        for (i in bars.indices) {
            bars[i] *= 0.8f
            if (bars[i] < 0.01f) bars[i] = 0f else any = true
        }
        if (any) invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val slot = width / bars.size.toFloat()
        val gap = slot * 0.2f
        for (i in bars.indices) {
            val h = bars[i] * (height - 8f)
            val left = i * slot + gap / 2
            canvas.drawRect(left, height - h - 4f, left + slot - gap, height - 4f, paint)
        }
    }
}
