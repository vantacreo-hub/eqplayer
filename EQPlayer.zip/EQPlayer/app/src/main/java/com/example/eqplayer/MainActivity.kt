package com.example.eqplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

data class Track(val id: Long, val title: String, val artist: String)

class MainActivity : Activity(), AudioEngine.Listener {

    private val tracks = ArrayList<Track>()
    @Volatile private var index = -1
    private lateinit var engine: AudioEngine
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var spectrum: SpectrumView
    private lateinit var nowPlaying: TextView
    private lateinit var timeText: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: Button
    private lateinit var presetSpinner: Spinner
    private lateinit var list: ListView
    private val sliders = ArrayList<BandSliderView>()
    private val presetNames = Presets.all.map { it.first } + "Custom"

    private var userSeeking = false
    private var updatingUi = false

    private val ticker = object : Runnable {
        override fun run() {
            if (engine.hasTrack) {
                if (!userSeeking) {
                    seek.max = engine.durationMs
                    seek.progress = engine.positionMs
                    timeText.text = "${fmt(engine.positionMs)} / ${fmt(engine.durationMs)}"
                }
            }
            if (!engine.isPlaying) spectrum.decay()
            handler.postDelayed(this, 300)
        }
    }

    // ------------------------------------------------------------ Lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("eq_prefs", MODE_PRIVATE)
        volumeControlStream = AudioManager.STREAM_MUSIC

        engine = AudioEngine(applicationContext, this)
        loadSettings()
        buildUi()
        handler.post(ticker)

        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            loadTracks()
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            loadTracks()
        } else {
            Toast.makeText(this, "Izin penyimpanan dibutuhkan untuk membaca musik", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        engine.release()
        super.onDestroy()
    }

    // ------------------------------------------------------------ Engine callbacks (thread audio)

    override fun onSpectrum(bars: FloatArray) {
        spectrum.update(bars)
    }

    override fun onCompleted() {
        val idx = index
        handler.post { if (idx == index) playNext() }
    }

    override fun onError(message: String) {
        handler.post {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            playBtn.text = "▶"
        }
    }

    // ------------------------------------------------------------ Pengaturan tersimpan

    private fun loadSettings() {
        val saved = prefs.getString("gains", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
        if (saved != null && saved.size == EqDsp.BANDS) engine.dsp.setAll(saved.toFloatArray())
        engine.dsp.enabled = prefs.getBoolean("dsp_on", true)
        engine.dsp.preampDb = prefs.getFloat("preamp", 0f)
        engine.limiterEnabled = prefs.getBoolean("limiter_on", true)
        engine.volume = prefs.getFloat("volume", 1f)
    }

    private fun saveGains() {
        val s = (0 until EqDsp.BANDS).joinToString(",") { engine.dsp.getGain(it).toString() }
        prefs.edit().putString("gains", s).apply()
    }

    // ------------------------------------------------------------ UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun title(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTextColor(Color.parseColor("#00E5A0"))
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(Color.LTGRAY)
        setPadding(0, dp(8), 0, 0)
    }

    private fun buildUi() {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }

        header.addView(TextView(this).apply {
            text = "EQ Player"
            textSize = 24f
            setTextColor(Color.WHITE)
        })
        header.addView(TextView(this).apply {
            text = "Decoder → PCM → DSP 30 band → Limiter → AudioTrack"
            textSize = 12f
            setTextColor(Color.GRAY)
        })

        spectrum = SpectrumView(this)
        header.addView(spectrum, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110)).apply {
            topMargin = dp(12)
        })

        nowPlaying = TextView(this).apply {
            text = "Pilih lagu dari daftar di bawah"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, 0)
            maxLines = 1
        }
        header.addView(nowPlaying)

        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) timeText.text = "${fmt(p)} / ${fmt(s?.max ?: 0)}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                userSeeking = false
                if (engine.hasTrack) engine.seekTo(seek.progress)
            }
        })
        header.addView(seek)

        timeText = TextView(this).apply {
            text = "0:00 / 0:00"
            setTextColor(Color.LTGRAY)
            gravity = Gravity.END
        }
        header.addView(timeText)

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        controls.addView(Button(this).apply { text = "⏮"; setOnClickListener { playPrev() } })
        playBtn = Button(this).apply { text = "▶"; setOnClickListener { togglePlay() } }
        controls.addView(playBtn)
        controls.addView(Button(this).apply { text = "⏭"; setOnClickListener { playNext() } })
        header.addView(controls)

        // ---- Volume
        header.addView(title("Volume & Limiter"))
        val volLabel = label("Volume: ${(engine.volume * 100).toInt()}%")
        header.addView(volLabel)
        header.addView(SeekBar(this).apply {
            max = 100
            progress = (engine.volume * 100).toInt()
            setOnSeekBarChangeListener(simpleListener { p ->
                engine.volume = p / 100f
                volLabel.text = "Volume: $p%"
                prefs.edit().putFloat("volume", p / 100f).apply()
            })
        })
        header.addView(Switch(this).apply {
            text = "Limiter aktif (cegah clipping)"
            setTextColor(Color.WHITE)
            isChecked = engine.limiterEnabled
            setOnCheckedChangeListener { _, on ->
                engine.limiterEnabled = on
                prefs.edit().putBoolean("limiter_on", on).apply()
            }
        })

        // ---- Equalizer 30 band
        header.addView(title("Equalizer 30 band"))
        header.addView(Switch(this).apply {
            text = "DSP aktif (matikan = bypass)"
            setTextColor(Color.WHITE)
            isChecked = engine.dsp.enabled
            setOnCheckedChangeListener { _, on ->
                engine.dsp.enabled = on
                prefs.edit().putBoolean("dsp_on", on).apply()
            }
        })

        val preLabel = label("Preamp: ${"%+d".format(engine.dsp.preampDb.toInt())} dB")
        header.addView(preLabel)
        header.addView(SeekBar(this).apply {
            max = 24
            progress = engine.dsp.preampDb.toInt() + 12
            setOnSeekBarChangeListener(simpleListener { p ->
                val db = p - 12
                engine.dsp.preampDb = db.toFloat()
                preLabel.text = "Preamp: ${"%+d".format(db)} dB"
                prefs.edit().putFloat("preamp", db.toFloat()).apply()
            })
        })

        presetSpinner = Spinner(this)
        presetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presetNames)
        presetSpinner.setSelection(presetNames.size - 1)
        presetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos >= Presets.all.size) return // "Custom"
                val g = Presets.all[pos].second
                engine.dsp.setAll(g)
                updatingUi = true
                for (i in 0 until EqDsp.BANDS) sliders[i].value = g[i]
                updatingUi = false
                saveGains()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        header.addView(presetSpinner)

        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = true }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until EqDsp.BANDS) {
            val s = BandSliderView(this, EqDsp.LABELS[i])
            s.value = engine.dsp.getGain(i)
            s.onChange = { v ->
                if (!updatingUi) {
                    engine.dsp.setGain(i, v)
                    saveGains()
                    presetSpinner.setSelection(presetNames.size - 1)
                }
            }
            sliders.add(s)
            row.addView(s, LinearLayout.LayoutParams(dp(46), dp(240)))
        }
        scroll.addView(row)
        header.addView(scroll)

        header.addView(title("Lagu"))

        list = ListView(this).apply {
            setBackgroundColor(Color.parseColor("#121212"))
            addHeaderView(header, null, false)
            setOnItemClickListener { _, _, pos, _ ->
                val i = pos - headerViewsCount
                if (i in tracks.indices) playIndex(i)
            }
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        setContentView(list)
    }

    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    // ------------------------------------------------------------ Musik

    private fun loadTracks() {
        tracks.clear()
        val cursor = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )
        cursor?.use {
            while (it.moveToNext()) {
                tracks.add(Track(it.getLong(0), it.getString(1) ?: "Tanpa judul", it.getString(2) ?: ""))
            }
        }
        val labels = tracks.map {
            if (it.artist.isBlank() || it.artist == "<unknown>") it.title else "${it.title} — ${it.artist}"
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        if (tracks.isEmpty()) Toast.makeText(this, "Tidak ada file musik ditemukan", Toast.LENGTH_LONG).show()
    }

    private fun playIndex(i: Int) {
        if (i !in tracks.indices) return
        index = i
        val t = tracks[i]
        engine.play(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, t.id))
        nowPlaying.text = t.title
        playBtn.text = "⏸"
        seek.progress = 0
    }

    private fun togglePlay() {
        if (index < 0) {
            if (tracks.isNotEmpty()) playIndex(0)
            return
        }
        if (!engine.hasTrack) { playIndex(index); return }
        if (engine.isPlaying) {
            engine.pause(); playBtn.text = "▶"
        } else {
            engine.resume(); playBtn.text = "⏸"
        }
    }

    private fun playNext() { if (tracks.isNotEmpty()) playIndex((index + 1) % tracks.size) }
    private fun playPrev() { if (tracks.isNotEmpty()) playIndex(if (index <= 0) tracks.size - 1 else index - 1) }

    private fun fmt(ms: Int): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }
}
