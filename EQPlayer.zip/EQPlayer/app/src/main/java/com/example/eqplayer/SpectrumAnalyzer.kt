package com.example.eqplayer

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** FFT 1024 titik dari PCM hasil olahan DSP, dikelompokkan menjadi 32 batang (40 Hz – 16 kHz). */
class SpectrumAnalyzer {

    companion object {
        const val BARS = 32
        private const val N = 1024
    }

    private val ring = FloatArray(N)
    private var pos = 0
    private val re = DoubleArray(N)
    private val im = DoubleArray(N)
    private val window = DoubleArray(N) { 0.5 - 0.5 * cos(2.0 * PI * it / (N - 1)) }

    fun push(sample: Float) {
        ring[pos] = sample
        pos = (pos + 1) and (N - 1)
    }

    fun compute(sampleRate: Int): FloatArray {
        for (i in 0 until N) {
            re[i] = ring[(pos + i) and (N - 1)] * window[i]
            im[i] = 0.0
        }
        fft()

        val out = FloatArray(BARS)
        val ratio = 16000.0 / 40.0
        for (b in 0 until BARS) {
            val f0 = 40.0 * ratio.pow(b / BARS.toDouble())
            val f1 = 40.0 * ratio.pow((b + 1) / BARS.toDouble())
            val hi = min((f1 * N / sampleRate).toInt().coerceAtLeast(2), N / 2 - 1)
            val lo = min((f0 * N / sampleRate).toInt().coerceAtLeast(1), hi - 1)
            var peak = 0.0
            for (k in lo..hi) peak = max(peak, hypot(re[k], im[k]))
            val amp = peak / (N / 4.0)            // amplitudo 1.0 → 0 dBFS
            val db = 20.0 * log10(amp + 1e-9)
            out[b] = ((db + 70.0) / 70.0).coerceIn(0.0, 1.0).toFloat()
        }
        return out
    }

    private fun fft() {
        // bit-reversal
        var j = 0
        for (i in 1 until N) {
            var bit = N shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= N) {
            val ang = -2.0 * PI / len
            val wr = cos(ang)
            val wi = sin(ang)
            var i = 0
            while (i < N) {
                var cr = 1.0
                var ci = 0.0
                for (k in 0 until len / 2) {
                    val ur = re[i + k]; val ui = im[i + k]
                    val vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci
                    val vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr
                    re[i + k] = ur + vr; im[i + k] = ui + vi
                    re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi
                    val nr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = nr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
