package com.example.eqplayer

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Equalizer grafis 30 band (1/3 oktaf, 25 Hz – 20 kHz).
 * Tiap band adalah filter biquad "peaking" (RBJ Audio EQ Cookbook), Q ≈ 4.318 (lebar 1/3 oktaf).
 * Pengaturan (gain) boleh diubah dari thread UI; pemrosesan berjalan di thread audio.
 */
class EqDsp {

    companion object {
        const val BANDS = 30
        const val MIN_DB = -12f
        const val MAX_DB = 12f
        private const val Q = 4.318

        val FREQS = floatArrayOf(
            25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f,
            250f, 315f, 400f, 500f, 630f, 800f, 1000f, 1250f, 1600f, 2000f,
            2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f, 16000f, 20000f
        )
        val LABELS = arrayOf(
            "25", "31", "40", "50", "63", "80", "100", "125", "160", "200",
            "250", "315", "400", "500", "630", "800", "1k", "1.2k", "1.6k", "2k",
            "2.5k", "3.1k", "4k", "5k", "6.3k", "8k", "10k", "12k", "16k", "20k"
        )
    }

    private val gains = FloatArray(BANDS)

    @Volatile var enabled = true
    @Volatile var preampDb = 0f
    @Volatile private var version = 0

    // Hanya diakses dari thread audio
    private var applied = -1
    private var appliedRate = 0
    private val b0 = DoubleArray(BANDS)
    private val b1 = DoubleArray(BANDS)
    private val b2 = DoubleArray(BANDS)
    private val a1 = DoubleArray(BANDS)
    private val a2 = DoubleArray(BANDS)
    private val active = BooleanArray(BANDS)
    private val z1 = DoubleArray(BANDS * 2)
    private val z2 = DoubleArray(BANDS * 2)

    fun setGain(band: Int, db: Float) {
        gains[band] = db.coerceIn(MIN_DB, MAX_DB)
        version++
    }

    fun getGain(band: Int): Float = gains[band]

    fun setAll(values: FloatArray) {
        for (i in 0 until BANDS) gains[i] = values[i].coerceIn(MIN_DB, MAX_DB)
        version++
    }

    /** Hapus memori filter (dipanggil saat seek). */
    fun reset() {
        z1.fill(0.0)
        z2.fill(0.0)
    }

    private fun recompute(sr: Int) {
        val v = version
        for (k in 0 until BANDS) {
            val g = gains[k]
            val f = FREQS[k]
            if (abs(g) < 0.05f || f >= sr * 0.45f) {
                active[k] = false
                z1[2 * k] = 0.0; z1[2 * k + 1] = 0.0
                z2[2 * k] = 0.0; z2[2 * k + 1] = 0.0
                continue
            }
            val a = 10.0.pow(g / 40.0)
            val w0 = 2.0 * PI * f / sr
            val alpha = sin(w0) / (2.0 * Q)
            val cosw = cos(w0)
            val a0 = 1.0 + alpha / a
            b0[k] = (1.0 + alpha * a) / a0
            b1[k] = (-2.0 * cosw) / a0
            b2[k] = (1.0 - alpha * a) / a0
            a1[k] = (-2.0 * cosw) / a0
            a2[k] = (1.0 - alpha / a) / a0
            active[k] = true
        }
        applied = v
        appliedRate = sr
    }

    /** Olah blok PCM float interleaved (-1..1) di tempat. */
    fun process(buf: FloatArray, frames: Int, channels: Int, sampleRate: Int) {
        if (!enabled) return
        if (applied != version || appliedRate != sampleRate) recompute(sampleRate)

        val pre = 10.0.pow(preampDb / 20.0).toFloat()
        if (pre != 1f) {
            for (i in 0 until frames * channels) buf[i] *= pre
        }

        for (k in 0 until BANDS) {
            if (!active[k]) continue
            val c0 = b0[k]; val c1 = b1[k]; val c2 = b2[k]
            val d1 = a1[k]; val d2 = a2[k]
            for (c in 0 until channels) {
                var s1 = z1[2 * k + c]
                var s2 = z2[2 * k + c]
                var idx = c
                for (f in 0 until frames) {
                    val x = buf[idx].toDouble()
                    val y = c0 * x + s1
                    s1 = c1 * x - d1 * y + s2
                    s2 = c2 * x - d2 * y
                    buf[idx] = y.toFloat()
                    idx += channels
                }
                z1[2 * k + c] = s1
                z2[2 * k + c] = s2
            }
        }
    }
}

/** Kumpulan preset: titik (Hz → dB) diinterpolasi pada skala log-frekuensi ke 30 band. */
object Presets {
    private fun curve(vararg pts: Pair<Float, Float>): FloatArray {
        if (pts.isEmpty()) return FloatArray(EqDsp.BANDS)
        return FloatArray(EqDsp.BANDS) { i ->
            val f = EqDsp.FREQS[i]
            when {
                f <= pts.first().first -> pts.first().second
                f >= pts.last().first -> pts.last().second
                else -> {
                    var j = 0
                    while (pts[j + 1].first < f) j++
                    val (f0, g0) = pts[j]
                    val (f1, g1) = pts[j + 1]
                    val t = (kotlin.math.ln(f / f0) / kotlin.math.ln(f1 / f0))
                    g0 + (g1 - g0) * t
                }
            }
        }
    }

    val all: List<Pair<String, FloatArray>> = listOf(
        "Flat" to curve(),
        "Bass Boost" to curve(25f to 7f, 63f to 6f, 125f to 4f, 250f to 1f, 500f to 0f),
        "Treble Boost" to curve(2000f to 0f, 4000f to 3f, 8000f to 6f, 16000f to 7f),
        "Vocal" to curve(25f to -3f, 125f to -2f, 400f to 0f, 1000f to 3f, 2500f to 4f, 5000f to 2f, 10000f to 0f, 20000f to -1f),
        "Rock" to curve(25f to 5f, 100f to 4f, 400f to -2f, 1000f to -1f, 3000f to 3f, 8000f to 5f, 20000f to 5f),
        "Pop" to curve(25f to -1f, 100f to 2f, 400f to 3f, 1000f to 3f, 3000f to 1f, 8000f to -1f, 20000f to -2f),
        "Jazz" to curve(25f to 3f, 100f to 3f, 400f to 1f, 1000f to -1f, 3000f to 0f, 8000f to 3f, 16000f to 4f),
        "Classical" to curve(25f to 4f, 100f to 3f, 400f to 0f, 2000f to 0f, 5000f to -2f, 10000f to -4f, 20000f to -4f),
        "Loudness" to curve(25f to 6f, 100f to 5f, 400f to 0f, 1000f to -1f, 3000f to 0f, 8000f to 4f, 16000f to 6f)
    )
}
