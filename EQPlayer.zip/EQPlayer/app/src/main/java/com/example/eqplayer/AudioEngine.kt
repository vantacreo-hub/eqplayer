package com.example.eqplayer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

/**
 * Jalur audio:
 *   Audio file decoder (MediaExtractor + MediaCodec)
 *     → PCM audio buffer (float, interleaved)
 *       → 30-band DSP (EqDsp)
 *         → Limiter / Volume
 *           → AudioTrack → Speaker / Headphone
 *
 * Seluruh jalur berjalan di satu thread khusus per lagu.
 */
class AudioEngine(private val ctx: Context, private val listener: Listener) {

    interface Listener {
        fun onSpectrum(bars: FloatArray)
        fun onCompleted()
        fun onError(message: String)
    }

    val dsp = EqDsp()
    @Volatile var volume = 1.0f
    @Volatile var limiterEnabled = true

    private var session: Session? = null

    val hasTrack: Boolean get() = session?.running == true
    val isPlaying: Boolean get() = session?.let { it.running && !it.paused } ?: false
    val positionMs: Int get() = session?.positionMs() ?: 0
    val durationMs: Int get() = session?.durationMs ?: 0

    fun play(uri: Uri) {
        stop()
        val s = Session(uri)
        session = s
        s.thread.start()
    }

    fun pause() { session?.paused = true }
    fun resume() { session?.paused = false }
    fun seekTo(ms: Int) { session?.seekReq?.set(ms.toLong()) }

    fun stop() {
        session?.let {
            it.stopFlag = true
            try { it.thread.join(2000) } catch (_: InterruptedException) { }
        }
        session = null
    }

    fun release() = stop()

    private inner class Session(val uri: Uri) {
        @Volatile var paused = false
        @Volatile var stopFlag = false
        @Volatile var running = true
        @Volatile var durationMs = 0
        @Volatile var framesWritten = 0L
        @Volatile var baseMs = 0L
        @Volatile var sampleRate = 44100
        val seekReq = AtomicLong(-1)
        val thread = Thread({ runLoop() }, "audio-engine")

        private var track: AudioTrack? = null
        private var channels = 2
        private var pcmFloat = false
        private var bufferFrames = 4096
        private var fbuf = FloatArray(0)
        private var sbuf = ShortArray(0)
        private var limGain = 1f
        private var lastSpectrum = 0L
        private val analyzer = SpectrumAnalyzer()

        fun positionMs(): Int = (baseMs + framesWritten * 1000L / sampleRate).toInt()

        private fun runLoop() {
            var extractor: MediaExtractor? = null
            var codec: MediaCodec? = null
            try {
                val ex = MediaExtractor()
                extractor = ex
                ex.setDataSource(ctx, uri, null)

                var idx = -1
                var inFormat: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                        idx = i; inFormat = f; break
                    }
                }
                if (idx < 0 || inFormat == null) {
                    if (!stopFlag) listener.onError("File ini tidak berisi audio")
                    return
                }
                ex.selectTrack(idx)
                if (inFormat.containsKey(MediaFormat.KEY_DURATION)) {
                    durationMs = (inFormat.getLong(MediaFormat.KEY_DURATION) / 1000).toInt()
                }

                val dec = MediaCodec.createDecoderByType(inFormat.getString(MediaFormat.KEY_MIME)!!)
                codec = dec
                dec.configure(inFormat, null, null, 0)
                dec.start()

                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false
                var doneAt = 0L

                while (!stopFlag) {
                    // --- seek ---
                    val req = seekReq.getAndSet(-1)
                    if (req >= 0) {
                        ex.seekTo(req * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                        dec.flush()
                        track?.let { it.pause(); it.flush(); it.play() }
                        dsp.reset()
                        limGain = 1f
                        inputDone = false
                        outputDone = false
                        doneAt = 0L
                        framesWritten = 0L
                        baseMs = req
                    }

                    // --- pause: berhenti mengisi buffer (AudioTrack kosong lalu senyap) ---
                    while (paused && !stopFlag && seekReq.get() < 0) Thread.sleep(20)
                    if (stopFlag) break
                    if (seekReq.get() >= 0) continue

                    // --- 1. Decoder: baca data terkompresi ---
                    if (!inputDone) {
                        val ii = dec.dequeueInputBuffer(0)
                        if (ii >= 0) {
                            val ib = dec.getInputBuffer(ii)!!
                            val n = ex.readSampleData(ib, 0)
                            if (n < 0) {
                                dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }

                    // --- 2. PCM buffer → DSP → Limiter → AudioTrack ---
                    if (!outputDone) {
                        val oi = dec.dequeueOutputBuffer(info, 5000)
                        when {
                            oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> setupOutput(dec.outputFormat)
                            oi >= 0 -> {
                                if (info.size > 0) {
                                    if (track == null) setupOutput(dec.outputFormat)
                                    val ob = dec.getOutputBuffer(oi)!!
                                    ob.position(info.offset)
                                    ob.limit(info.offset + info.size)
                                    processAndWrite(ob, info.size)
                                }
                                dec.releaseOutputBuffer(oi, false)
                                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                                    outputDone = true
                                    doneAt = SystemClock.elapsedRealtime()
                                }
                            }
                        }
                    } else {
                        // tunggu sisa buffer AudioTrack selesai diputar
                        Thread.sleep(30)
                        val drainMs = bufferFrames * 1000L / sampleRate + 80
                        if (SystemClock.elapsedRealtime() - doneAt > drainMs) {
                            if (!stopFlag) {
                                running = false
                                listener.onCompleted()
                            }
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                if (!stopFlag) listener.onError(e.message ?: "Gagal memutar file")
            } finally {
                running = false
                try { codec?.stop() } catch (_: Exception) { }
                try { codec?.release() } catch (_: Exception) { }
                try { extractor?.release() } catch (_: Exception) { }
                try { track?.release() } catch (_: Exception) { }
            }
        }

        private fun setupOutput(format: MediaFormat) {
            val sr = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val ch = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            pcmFloat = format.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                format.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
            if (ch > 2) throw IllegalStateException("Audio dengan lebih dari 2 kanal belum didukung")
            if (track != null && sr == sampleRate && ch == channels) return

            track?.release()
            sampleRate = sr
            channels = ch
            val mask = if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val minBuf = AudioTrack.getMinBufferSize(sr, mask, AudioFormat.ENCODING_PCM_16BIT)
            val bytes = maxOf(minBuf * 4, 8192)
            bufferFrames = bytes / (2 * ch)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(mask)
                        .build()
                )
                .setBufferSizeInBytes(bytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            t.play()
            track = t
        }

        private fun processAndWrite(ob: ByteBuffer, size: Int) {
            val t = track ?: return
            val ch = channels
            ob.order(ByteOrder.LITTLE_ENDIAN)
            val samples = if (pcmFloat) size / 4 else size / 2
            val frames = samples / ch
            val n = frames * ch
            if (n == 0) return
            if (fbuf.size < n) {
                fbuf = FloatArray(n)
                sbuf = ShortArray(n)
            }

            // PCM → float
            if (pcmFloat) {
                ob.asFloatBuffer().get(fbuf, 0, n)
            } else {
                ob.asShortBuffer().get(sbuf, 0, n)
                for (i in 0 until n) fbuf[i] = sbuf[i] / 32768f
            }

            // 30-band DSP
            dsp.process(fbuf, frames, ch, sampleRate)

            // Volume + limiter
            val vol = volume
            val lim = limiterEnabled
            var g = limGain
            for (f in 0 until frames) {
                val base = f * ch
                var peak = 0f
                for (c in 0 until ch) {
                    val x = fbuf[base + c] * vol
                    fbuf[base + c] = x
                    val a = abs(x)
                    if (a > peak) peak = a
                }
                if (lim) {
                    if (peak * g > CEILING) g = CEILING / peak else g += (1f - g) * RELEASE
                    for (c in 0 until ch) fbuf[base + c] *= g
                }
                var mono = 0f
                for (c in 0 until ch) {
                    val y = fbuf[base + c].coerceIn(-1f, 1f)
                    fbuf[base + c] = y
                    mono += y
                }
                analyzer.push(mono / ch)
            }
            limGain = g

            // float → PCM 16-bit → AudioTrack
            for (i in 0 until n) {
                sbuf[i] = (fbuf[i] * 32767f).toInt().coerceIn(-32768, 32767).toShort()
            }
            t.write(sbuf, 0, n)
            framesWritten += frames

            val now = SystemClock.elapsedRealtime()
            if (now - lastSpectrum >= 45) {
                lastSpectrum = now
                listener.onSpectrum(analyzer.compute(sampleRate))
            }
        }
    }

    private companion object {
        const val CEILING = 0.97f
        const val RELEASE = 0.0008f
    }
}
